﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    class productInfo
    {
        public string name;
        public string category;
        public int price;
        public int stock;
        public int minimumStock;

        public productInfo()
        {

        }
        public productInfo addProduct(productInfo p)
        {
            Console.Write("Enter Name of Product: ");
            p.name = Console.ReadLine();
            Console.Write("Enter category of product: ");
            p.category = Console.ReadLine();
            Console.Write("Enter Price of Product: ");
            p.price = int.Parse(Console.ReadLine());
            Console.Write("Enter Stock of Product: ");
            p.stock = int.Parse(Console.ReadLine());
            Console.Write("Enter Minimum Stock of Product: ");
            p.minimumStock = int.Parse(Console.ReadLine());
            return p;
        }

    }
}
