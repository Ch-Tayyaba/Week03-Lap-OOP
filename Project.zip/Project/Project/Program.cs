﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    class Program
    {
        static void Main(string[] args)
        {
            int option;
            List<productInfo> products = new List<productInfo>();
            do
            {
                Console.Clear();
                menu();
                Console.Write("Enter Option: ");
                option = int.Parse(Console.ReadLine());
                if (option == 1)
                {
                    productInfo p = new productInfo();
                    Console.Clear();
                    products.Add(p.addProduct(p));
                }
                if (option == 2)
                {
                    Console.Clear();
                    ViewInfo(products);
                }
                if (option == 3)
                {
                    Console.Clear();
                    HighestPrice(products);
                }
                if (option == 4)
                {
                    Console.Clear();
                    salesTax(products);
                }
                if (option == 5)
                {
                    Console.Clear();
                    forOrder(products);
                }

            } while (option < 6);
        }
        static void menu()
        {
            Console.WriteLine("1.Add Product.");
            Console.WriteLine("2.View all Products.");
            Console.WriteLine("3.Find Product with Highest Unit Price.");
            Console.WriteLine("4.View sales tax of all Products.");
            Console.WriteLine("5.Products to be ordered.");
        }
        static void ViewInfo(List<productInfo> products)
        {

            for (int idx = 0; idx < products.Count; idx++)
            {
                Console.WriteLine("Name: {0}     Category: {1}     Price: {2}     Stock: {3}        Minimun stock: {4}", products[idx].name, products[idx].category, products[idx].price, products[idx].stock, products[idx].minimumStock);
            }

        }
        static void HighestPrice(List<productInfo> products)
        {
            bool flag = false;
            int index = 0;
            int price = -1;
            for (int idx = 0; idx < products.Count; idx++)
            {
                if(price < products[idx].price)
                {
                    price = products[idx].price;
                    index = idx;
                    flag = true;
                }
            }
            if (flag == true)
            {
                Console.WriteLine("The Product having highest unit price.");
                Console.WriteLine("Name: {0}     Category: {1}     Price: {2}     Stock: {3}        Minimun stock: {4}", products[index].name, products[index].category, products[index].price, products[index].stock, products[index].minimumStock);
            }
            if (flag == false)
            {
                Console.WriteLine("There is no record yet.");
            }
            Console.ReadKey();
        }
        static void salesTax(List<productInfo> products)
        {
            int salesTax = 0;
            for (int idx = 0; idx < products.Count; idx++)
            {
                if(products[idx].category == "grocery")
                {
                    salesTax = salesTax + products[idx].stock * ((10 * products[idx].price) / 100);
                }
                if (products[idx].category == "fruit")
                {
                    salesTax = salesTax + products[idx].stock * ((5 * products[idx].price) / 100);
                }
            }
            Console.WriteLine("Total sales Tax of all products is: {0}", salesTax);
            Console.ReadKey();
        }
        static void forOrder(List<productInfo> products)
        {
            Console.WriteLine("Products To Be Ordered: ");
            for (int idx = 0; idx < products.Count; idx++)
            {
                if(products[idx].stock < products[idx].minimumStock)
                {
                    Console.WriteLine("Name: {0}     Category: {1}     Price: {2}     Stock: {3}        Minimun stock: {4}", products[index].name, products[index].category, products[index].price, products[index].stock, products[index].minimumStock); ;
                }
            }
            Console.ReadKey();
        }
    }
}
