﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClockTypeClass
{
    class clockType
    {
        public int hour;
        public int minute;
        public int second;
        public int elapsed;
        public int remaining;
        public clockType()
        {
            hour = 0;
            minute = 0;
            second = 0;
        }
        public clockType(int h)
        {
            hour = h;
        }
        public clockType(int h, int m)
        {
            hour = h;
            minute = m;
        }
        public clockType(int h, int m, int s)
        {
            hour = h;
            minute = m;
            second = s;
        }
        public void incrementHour()
        {
            hour++;
        }
        public void incrementMinute()
        {
            minute++;
        }
        public void incrementSecond()
        {
            second++;
        }
        public void printTime()
        {
            Console.WriteLine(hour + " " + minute + " " + second);
        }
        public bool isEqual(int h, int m, int s)
        {
            if(hour == h && minute == m && second == s)
            {
                return true;
            }
            return false;
        }
        public bool isEqual(clockType T)
        {
            if(hour == T.hour && minute == T.minute && second == T.second)
            {
                return true;
            }
            return false;
        }
        public int convertToSecond()
        {
            int totalTime = 0;
            totalTime = (hour * 3600);
            totalTime = totalTime + (minute * 60) + second;
            return totalTime;
        }
        public void elapsedTime()
        {
            elapsed = convertToSecond();
        }
        public void remainingTime()
        {
            int time = convertToSecond();
            remaining = 86400 - time;
        }
        public clockType differenceInTime(clockType c)
        {
            clockType n = new clockType();
            n.hour = c.hour - hour;
            n.minute = c.minute - minute;
            n.second = c.second - second;
            if(n.hour < 0)
            {
                n.hour = -1 * n.hour;
            }
            if (n.minute < 0)
            {
                n.minute = -1 * n.minute;
            }
            if (n.second < 0)
            {
                n.second = -1 * n.second;
            }
            return n;
        }
        public void convert(int time)
        {
            int temp;
            hour = time / 3600;
            temp = time % 3600;
            minute = temp / 60;
            second = temp % 60;
        }
    }
}
