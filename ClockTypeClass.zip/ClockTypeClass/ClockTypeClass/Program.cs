﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClockTypeClass
{
    class Program
    {
        static void Main(string[] args)
        {
            clockType emptyTime = new clockType();
            Console.Write("Empty Time: ");
            emptyTime.printTime();

            clockType hourTime = new clockType(8);
            Console.Write("Hour Time: ");
            hourTime.printTime();

            clockType minuteTime = new clockType(8,10);
            Console.Write("Minute Time: ");
            minuteTime.printTime();

            clockType fullTime = new clockType(8,10,10);
            Console.Write("Full Time: ");
            fullTime.printTime();

            fullTime.incrementSecond();
            Console.Write("Full time (Increment Second): ");
            fullTime.printTime();

            fullTime.incrementMinute();
            Console.Write("Full time (Increment Minute): ");
            fullTime.printTime();

            fullTime.incrementHour();
            Console.Write("Full time (Increment Hour): ");
            fullTime.printTime();

            bool flag = fullTime.isEqual(9, 11, 11);
            Console.WriteLine("Flag: {0}", flag);

            clockType cmp = new clockType(10, 12, 1);
            flag = fullTime.isEqual(cmp);
            Console.WriteLine("Object Flag: {0}", flag);

            clockType clock = new clockType(8,10,9);
            clock.convertToSecond();
            clock.elapsedTime();
            Console.WriteLine("Elapsed Time in Seconds: {0}", clock.elapsed);
            clock.convert(clock.elapsed);
            Console.Write("Elapsed Time: ");
            clock.printTime();

            clock.convertToSecond();
            clock.remainingTime();
            Console.WriteLine("Remaining Time in Seconds: {0}", clock.remaining);
            clock.convert(clock.remaining);
            Console.Write("Remaining Time: ");
            clock.printTime();

            clockType newClock = new clockType(10,8,5);
            clockType difference = new clockType();
            difference = clock.differenceInTime(newClock);
            Console.Write("Difference In Time: ");
            difference.printTime();

            Console.ReadKey();

        }
    }
}
