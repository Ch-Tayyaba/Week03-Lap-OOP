﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationUsingClass
{
    class userInfo
    {
        public string names;
        public string degree;
        public string totalMarks;
        public string obtMarks;
        public string fee;
    }
}
