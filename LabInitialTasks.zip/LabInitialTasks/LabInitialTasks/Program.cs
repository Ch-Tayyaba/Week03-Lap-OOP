﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabInitialTasks
{
    class Program
    {
        static void Main(string[] args)
        {
            forEachLoop();
        }
        static void copyConstuctor()
        {
            student s1 = new student();
            s1.sname = "Jack";
            student s2 = new student(s1);
            Console.WriteLine(s1.sname);
            Console.WriteLine(s2.sname);
            Console.ReadKey();
        }
        static void forEachLoop()
        {
            List<int> numbers = new List<int>() {1,2,3,4,5,6,7,8,9,10 };
            foreach(var i in numbers)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
